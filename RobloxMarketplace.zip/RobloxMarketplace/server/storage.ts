import {
  users,
  products,
  orders,
  apiKeys,
  type User,
  type UpsertUser,
  type Product,
  type InsertProduct,
  type Order,
  type InsertOrder,
  type ApiKey,
  type InsertApiKey,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import { nanoid } from "nanoid";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeCustomerId(userId: string, customerId: string): Promise<User>;
  updateUserCredits(userId: string, credits: number): Promise<User>;

  // Product operations
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;

  // Order operations
  createOrder(order: InsertOrder): Promise<Order>;
  getOrdersByUser(userId: string): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  updateOrderStatus(id: number, status: string, deliveredAt?: Date): Promise<Order>;
  getAllOrders(): Promise<(Order & { user: User; product: Product })[]>;

  // API Key operations
  getApiKeys(): Promise<ApiKey[]>;
  getApiKey(key: string): Promise<ApiKey | undefined>;
  createApiKey(apiKey: Omit<InsertApiKey, 'id' | 'key'>): Promise<ApiKey>;
  updateApiKey(id: string, apiKey: Partial<InsertApiKey>): Promise<ApiKey>;
  deleteApiKey(id: string): Promise<void>;
  
  // Credits operations
  addCreditsToUser(userId: string, credits: number, apiKeyId: string): Promise<User>;
  purchaseWithCredits(userId: string, productId: number): Promise<{ user: User; order: Order }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStripeCustomerId(userId: string, customerId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ stripeCustomerId: customerId, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserCredits(userId: string, credits: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ credits, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Product operations
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.isActive, true));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product> {
    const [updatedProduct] = await db
      .update(products)
      .set({ ...product, updatedAt: new Date() })
      .where(eq(products.id, id))
      .returning();
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<void> {
    await db.update(products).set({ isActive: false }).where(eq(products.id, id));
  }

  // Order operations
  async createOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }

  async getOrdersByUser(userId: string): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  }

  async updateOrderStatus(id: number, status: string, deliveredAt?: Date): Promise<Order> {
    const [updatedOrder] = await db
      .update(orders)
      .set({ status, deliveredAt })
      .where(eq(orders.id, id))
      .returning();
    return updatedOrder;
  }

  async getAllOrders(): Promise<(Order & { user: User; product: Product })[]> {
    const result = await db
      .select()
      .from(orders)
      .innerJoin(users, eq(orders.userId, users.id))
      .innerJoin(products, eq(orders.productId, products.id))
      .orderBy(desc(orders.createdAt));

    return result.map((row) => ({
      ...row.orders,
      user: row.users,
      product: row.products,
    }));
  }

  // API Key operations
  async getApiKeys(): Promise<ApiKey[]> {
    return await db.select().from(apiKeys).orderBy(desc(apiKeys.createdAt));
  }

  async getApiKey(key: string): Promise<ApiKey | undefined> {
    const [apiKey] = await db.select().from(apiKeys).where(eq(apiKeys.key, key));
    return apiKey;
  }

  async createApiKey(apiKeyData: Omit<InsertApiKey, 'id' | 'key'>): Promise<ApiKey> {
    const id = nanoid();
    const key = `ahx_${nanoid(32)}`;
    const [newApiKey] = await db
      .insert(apiKeys)
      .values({ ...apiKeyData, id, key })
      .returning();
    return newApiKey;
  }

  async updateApiKey(id: string, apiKeyData: Partial<InsertApiKey>): Promise<ApiKey> {
    const [updatedApiKey] = await db
      .update(apiKeys)
      .set({ ...apiKeyData, updatedAt: new Date() })
      .where(eq(apiKeys.id, id))
      .returning();
    return updatedApiKey;
  }

  async deleteApiKey(id: string): Promise<void> {
    await db.update(apiKeys).set({ isActive: false }).where(eq(apiKeys.id, id));
  }

  // Credits operations
  async addCreditsToUser(userId: string, credits: number, apiKeyId: string): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error('User not found');
    
    const newCredits = (user.credits || 0) + credits;
    return await this.updateUserCredits(userId, newCredits);
  }

  async purchaseWithCredits(userId: string, productId: number): Promise<{ user: User; order: Order }> {
    const user = await this.getUser(userId);
    const product = await this.getProduct(productId);
    
    if (!user) throw new Error('User not found');
    if (!product) throw new Error('Product not found');
    if ((user.credits || 0) < (product.creditsPrice || 0)) {
      throw new Error('Insufficient credits');
    }

    // Deduct credits
    const newCredits = (user.credits || 0) - (product.creditsPrice || 0);
    const updatedUser = await this.updateUserCredits(userId, newCredits);

    // Create order
    const order = await this.createOrder({
      userId,
      productId,
      amount: "0", // Free since paid with credits
      status: "completed",
      deliveredAt: new Date(),
    });

    return { user: updatedUser, order };
  }
}

export const storage = new DatabaseStorage();
