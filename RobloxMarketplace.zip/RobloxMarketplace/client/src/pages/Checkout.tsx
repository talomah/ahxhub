import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Navigation } from '@/components/Navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/hooks/useAuth';
import { isUnauthorizedError } from '@/lib/authUtils';

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const CheckoutForm = ({ productInfo }: { productInfo: any }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    if (!stripe || !elements) {
      setIsProcessing(false);
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/dashboard?payment=success`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    }
    
    setIsProcessing(false);
  };

  return (
    <div className="max-w-md mx-auto">
      <Card className="glass-dark border-white/20">
        <CardHeader>
          <CardTitle className="text-white dark:text-white text-center">Complete Your Purchase</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {productInfo && (
            <div className="text-center space-y-2 p-4 border border-white/20 rounded-lg">
              <h3 className="font-semibold text-white dark:text-white">{productInfo.productName}</h3>
              <p className="text-2xl font-bold text-coral">${productInfo.amount}</p>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <PaymentElement />
            <Button 
              type="submit" 
              disabled={!stripe || isProcessing}
              className="w-full bg-coral hover:bg-coral/80 text-white py-3"
            >
              {isProcessing ? 'Processing...' : `Pay $${productInfo?.amount || '0'}`}
            </Button>
          </form>
          
          <div className="text-center text-xs text-gray-400 dark:text-gray-400">
            Your payment is secured by Stripe. Files will be delivered instantly to your Discord.
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default function Checkout() {
  const [clientSecret, setClientSecret] = useState("");
  const [productInfo, setProductInfo] = useState<any>(null);
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  useEffect(() => {
    if (!isAuthenticated) return;

    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('productId') || '1';

    apiRequest("POST", "/api/create-payment-intent", { productId: parseInt(productId) })
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
        setProductInfo({
          productName: data.productName,
          amount: data.amount,
        });
      })
      .catch((error) => {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
          return;
        }
        toast({
          title: "Error",
          description: "Failed to initialize payment. Please try again.",
          variant: "destructive",
        });
      });
  }, [isAuthenticated, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <div className="pt-20 min-h-screen flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-coral border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <div className="pt-20 min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-coral border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-gray-300 dark:text-gray-300">Preparing checkout...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="pt-20 min-h-screen flex items-center justify-center px-4">
        <Elements stripe={stripePromise} options={{ clientSecret }}>
          <CheckoutForm productInfo={productInfo} />
        </Elements>
      </div>
    </div>
  );
}
