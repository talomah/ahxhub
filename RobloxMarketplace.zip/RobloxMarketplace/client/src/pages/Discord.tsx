import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { MessageCircle, Users, Shield, Zap, Crown, Star } from 'lucide-react';

export default function Discord() {
  return (
    <div className="min-h-screen ahx-bg-primary">
      <Navigation />
      
      <section className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-6">
          {/* Hero Section */}
          <div className="text-center mb-20">
            <h1 className="text-6xl ahx-futuristic-text ahx-text-red mb-8 ahx-glow-red">
              JOIN OUR DISCORD
            </h1>
            <p className="text-2xl ahx-text-white mb-4">
              Connect with elite developers and get exclusive access
            </p>
            <p className="text-xl ahx-text-gray max-w-3xl mx-auto mb-12">
              Our Discord server is the hub for premium Roblox development. Get instant support, 
              exclusive previews, and connect with a community of professional creators.
            </p>
            
            <Button 
              onClick={() => window.open('https://discord.gg/your-server', '_blank')}
              className="ahx-bg-red-glow ahx-text-white px-12 py-6 text-xl ahx-futuristic-text hover:ahx-hover-glow"
              size="lg"
            >
              <MessageCircle className="mr-3 w-6 h-6" />
              JOIN DISCORD
            </Button>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
            <div className="ahx-card p-8 text-center ahx-hover-glow">
              <Users className="w-16 h-16 ahx-text-red mx-auto mb-6" />
              <h3 className="text-2xl font-bold ahx-text-white mb-4">Premium Community</h3>
              <p className="ahx-text-gray">
                Connect with verified developers and elite scripters in our exclusive channels
              </p>
            </div>
            
            <div className="ahx-card p-8 text-center ahx-hover-glow">
              <Shield className="w-16 h-16 ahx-text-red mx-auto mb-6" />
              <h3 className="text-2xl font-bold ahx-text-white mb-4">Instant Support</h3>
              <p className="ahx-text-gray">
                Get 24/7 technical support and assistance from our expert team
              </p>
            </div>
            
            <div className="ahx-card p-8 text-center ahx-hover-glow">
              <Crown className="w-16 h-16 ahx-text-red mx-auto mb-6" />
              <h3 className="text-2xl font-bold ahx-text-white mb-4">Exclusive Access</h3>
              <p className="ahx-text-gray">
                Early access to new releases and member-only content and tutorials
              </p>
            </div>
            
            <div className="ahx-card p-8 text-center ahx-hover-glow">
              <Zap className="w-16 h-16 ahx-text-red mx-auto mb-6" />
              <h3 className="text-2xl font-bold ahx-text-white mb-4">Fast Delivery</h3>
              <p className="ahx-text-gray">
                Instant file delivery through our automated Discord bot system
              </p>
            </div>
            
            <div className="ahx-card p-8 text-center ahx-hover-glow">
              <Star className="w-16 h-16 ahx-text-red mx-auto mb-6" />
              <h3 className="text-2xl font-bold ahx-text-white mb-4">Premium Updates</h3>
              <p className="ahx-text-gray">
                Stay updated with the latest releases and exclusive announcements
              </p>
            </div>
            
            <div className="ahx-card p-8 text-center ahx-hover-glow">
              <MessageCircle className="w-16 h-16 ahx-text-red mx-auto mb-6" />
              <h3 className="text-2xl font-bold ahx-text-white mb-4">Live Chat</h3>
              <p className="ahx-text-gray">
                Real-time discussions with developers and community members
              </p>
            </div>
          </div>

          {/* Discord Preview */}
          <div className="ahx-card p-8 text-center">
            <h3 className="text-3xl font-bold ahx-text-white mb-6">
              Join 10,000+ Elite Developers
            </h3>
            <div className="grid md:grid-cols-3 gap-8 mb-8">
              <div>
                <div className="text-4xl font-bold ahx-text-red mb-2">10K+</div>
                <div className="ahx-text-gray">Active Members</div>
              </div>
              <div>
                <div className="text-4xl font-bold ahx-text-red mb-2">50+</div>
                <div className="ahx-text-gray">Expert Developers</div>
              </div>
              <div>
                <div className="text-4xl font-bold ahx-text-red mb-2">24/7</div>
                <div className="ahx-text-gray">Community Support</div>
              </div>
            </div>
            
            <div className="max-w-2xl mx-auto ahx-gradient-bg p-8 rounded-lg border ahx-border-red">
              <p className="ahx-text-white mb-4 text-lg">
                "AHX Hub's Discord is where I found the best assets and connected with 
                amazing developers. The community support is unmatched!"
              </p>
              <div className="flex items-center justify-center space-x-1 mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 ahx-text-red fill-current" />
                ))}
              </div>
              <p className="ahx-text-gray">- Elite Developer</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}