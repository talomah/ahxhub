import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Product } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Code, Star, Download, Shield, Zap } from 'lucide-react';
import { Link } from 'wouter';
import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';

export default function Products() {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen ahx-gradient-bg">
        <Navigation />
        <div className="pt-32 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin w-16 h-16 ahx-border-red border-4 border-t-transparent rounded-full mx-auto mb-4" />
            <p className="ahx-text-white text-xl">Loading premium assets...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen ahx-gradient-bg">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-24 lg:pt-32 pb-12 lg:pb-20">
        <div className="max-w-7xl mx-auto px-4 lg:px-6">
          <div className="text-center mb-12 lg:mb-16">
            <h1 className="text-3xl sm:text-5xl lg:text-6xl ahx-futuristic-text ahx-text-red mb-4 lg:mb-6 ahx-glow-red">
              PREMIUM ASSETS
            </h1>
            <p className="text-base lg:text-xl ahx-text-gray max-w-3xl mx-auto px-4">
              Elite Roblox assets designed for professionals. 
              Every asset is meticulously crafted and thoroughly tested.
            </p>
          </div>

          {/* Categories */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 mb-12 lg:mb-16">
            <div className="ahx-card p-6 lg:p-8 text-center ahx-hover-glow">
              <Code className="w-12 lg:w-16 h-12 lg:h-16 ahx-text-red mx-auto mb-3 lg:mb-4" />
              <h3 className="text-lg lg:text-2xl font-bold ahx-text-white mb-2">Premium Assets</h3>
              <p className="ahx-text-gray text-sm lg:text-base">High-quality Roblox assets with premium features</p>
            </div>
            <div className="ahx-card p-6 lg:p-8 text-center ahx-hover-glow">
              <Shield className="w-12 lg:w-16 h-12 lg:h-16 ahx-text-red mx-auto mb-3 lg:mb-4" />
              <h3 className="text-lg lg:text-2xl font-bold ahx-text-white mb-2">Secure & Tested</h3>
              <p className="ahx-text-gray text-sm lg:text-base">All assets are thoroughly tested and secure</p>
            </div>
            <div className="ahx-card p-6 lg:p-8 text-center ahx-hover-glow col-span-1 sm:col-span-2 lg:col-span-1">
              <Zap className="w-12 lg:w-16 h-12 lg:h-16 ahx-text-red mx-auto mb-3 lg:mb-4" />
              <h3 className="text-lg lg:text-2xl font-bold ahx-text-white mb-2">Performance</h3>
              <p className="ahx-text-gray text-sm lg:text-base">Optimized for maximum performance and reliability</p>
            </div>
          </div>

          {/* Products Grid */}
          {products && products.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product) => (
                <Card key={product.id} className="ahx-card ahx-hover-glow overflow-hidden">
                  <div className="relative">
                    <div className="aspect-video ahx-gradient-bg flex items-center justify-center">
                      <Code className="w-16 h-16 ahx-text-red opacity-50" />
                    </div>
                    <div className="absolute top-4 right-4 px-3 py-1 ahx-bg-red-glow rounded-full">
                      <span className="text-sm font-bold ahx-text-white">PREMIUM</span>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold ahx-text-white mb-2">{product.name}</h3>
                    <p className="ahx-text-gray mb-4 text-sm">{product.description}</p>
                    
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-3xl font-bold ahx-text-red">${product.price}</span>
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 ahx-text-red fill-current" />
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Link href="/product" className="flex-1">
                        <Button className="w-full ahx-bg-red-glow ahx-text-white hover:ahx-hover-glow">
                          <Download className="w-4 h-4 mr-2" />
                          Get Access
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Code className="w-24 h-24 ahx-text-red opacity-50 mx-auto mb-6" />
              <h3 className="text-2xl font-bold ahx-text-white mb-4">No Products Available</h3>
              <p className="ahx-text-gray">Premium assets are being prepared. Check back soon!</p>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}