import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { isUnauthorizedError } from '@/lib/authUtils';
import { apiRequest } from '@/lib/queryClient';
import { useEffect, useState } from 'react';
import { Product, Order, User, ApiKey } from '@shared/schema';
import { DollarSign, Package, Users, TrendingUp, Edit, Trash2, Plus, Key, Copy } from 'lucide-react';

export default function Admin() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showApiKeyForm, setShowApiKeyForm] = useState(false);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }

    if (!isLoading && isAuthenticated && user?.email !== 'talonlol69420@gmail.com') {
      toast({
        title: "Access Denied",
        description: "Admin access required.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, user, toast]);

  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ['/api/products'],
    enabled: isAuthenticated,
  });

  const { data: orders = [] } = useQuery<(Order & { user: User; product: Product })[]>({
    queryKey: ['/api/admin/orders'],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: apiKeys = [] } = useQuery<ApiKey[]>({
    queryKey: ['/api/admin/api-keys'],
    enabled: isAuthenticated,
    retry: false,
  });

  const createProductMutation = useMutation({
    mutationFn: async (productData: any) => {
      await apiRequest('POST', '/api/admin/products', productData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setShowProductForm(false);
      toast({
        title: "Success",
        description: "Product created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create product",
        variant: "destructive",
      });
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      await apiRequest('PUT', `/api/admin/products/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setEditingProduct(null);
      toast({
        title: "Success",
        description: "Product updated successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update product",
        variant: "destructive",
      });
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/admin/products/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({
        title: "Success",
        description: "Product deleted successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete product",
        variant: "destructive",
      });
    },
  });

  const createApiKeyMutation = useMutation({
    mutationFn: async (apiKeyData: { name: string; creditsPerDollar: number }) => {
      await apiRequest('POST', '/api/admin/api-keys', apiKeyData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/api-keys'] });
      setShowApiKeyForm(false);
      toast({
        title: "Success",
        description: "API key created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create API key",
        variant: "destructive",
      });
    },
  });

  const deleteApiKeyMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/admin/api-keys/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/api-keys'] });
      toast({
        title: "Success",
        description: "API key deleted successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete API key",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "API key copied to clipboard",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <div className="pt-20 min-h-screen flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-coral border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  const totalRevenue = orders.reduce((sum, order) => sum + parseFloat(order.amount.toString()), 0);
  const completedOrders = orders.filter(order => order.status === 'completed');

  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const productData = {
      name: formData.get('name') as string,
      description: formData.get('description') as string,
      price: formData.get('price') as string,
      creditsPrice: parseInt(formData.get('creditsPrice') as string) || 0,
      fileUrl: formData.get('fileUrl') as string,
      fileName: formData.get('fileName') as string,
    };

    if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, data: productData });
    } else {
      createProductMutation.mutate(productData);
    }
  };

  const handleApiKeySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const apiKeyData = {
      name: formData.get('name') as string,
      creditsPerDollar: parseInt(formData.get('creditsPerDollar') as string) || 100,
    };
    createApiKeyMutation.mutate(apiKeyData);
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="pt-20 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="space-y-8">
            <div className="text-center space-y-4">
              <h1 className="text-4xl font-bold text-white dark:text-white">Admin Panel</h1>
              <p className="text-xl text-gray-300 dark:text-gray-300">
                Manage products and monitor performance
              </p>
            </div>

            {/* Stats Cards */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="glass-dark border-white/20">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-coral to-electric rounded-lg mx-auto mb-4 flex items-center justify-center">
                    <DollarSign className="text-white" />
                  </div>
                  <div className="text-3xl font-bold text-coral">${totalRevenue.toFixed(2)}</div>
                  <div className="text-sm text-gray-400 dark:text-gray-400">Revenue</div>
                </CardContent>
              </Card>

              <Card className="glass-dark border-white/20">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-coral to-electric rounded-lg mx-auto mb-4 flex items-center justify-center">
                    <TrendingUp className="text-white" />
                  </div>
                  <div className="text-3xl font-bold text-electric">{orders.length}</div>
                  <div className="text-sm text-gray-400 dark:text-gray-400">Orders</div>
                </CardContent>
              </Card>

              <Card className="glass-dark border-white/20">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-coral to-electric rounded-lg mx-auto mb-4 flex items-center justify-center">
                    <Package className="text-white" />
                  </div>
                  <div className="text-3xl font-bold text-white dark:text-white">{products.length}</div>
                  <div className="text-sm text-gray-400 dark:text-gray-400">Products</div>
                </CardContent>
              </Card>

              <Card className="glass-dark border-white/20">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-coral to-electric rounded-lg mx-auto mb-4 flex items-center justify-center">
                    <Users className="text-white" />
                  </div>
                  <div className="text-3xl font-bold text-yellow-400">4.9</div>
                  <div className="text-sm text-gray-400 dark:text-gray-400">Avg Rating</div>
                </CardContent>
              </Card>
            </div>

            {/* API Keys Management */}
            <Card className="glass-dark border-white/20 mb-8">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-white dark:text-white flex items-center gap-2">
                  <Key className="w-5 h-5" />
                  API Keys for Roblox Integration
                </CardTitle>
                <Button
                  onClick={() => setShowApiKeyForm(!showApiKeyForm)}
                  className="bg-coral hover:bg-coral/80 text-white"
                  size="sm"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create API Key
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                {showApiKeyForm && (
                  <form onSubmit={handleApiKeySubmit} className="space-y-4 p-4 border border-white/20 rounded-lg">
                    <div>
                      <Label htmlFor="apiKeyName" className="text-white dark:text-white">API Key Name</Label>
                      <Input
                        id="apiKeyName"
                        name="name"
                        className="bg-white/10 border-white/20 text-white"
                        placeholder="e.g., Main Game API"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="creditsPerDollar" className="text-white dark:text-white">Credits per Dollar</Label>
                      <Input
                        id="creditsPerDollar"
                        name="creditsPerDollar"
                        type="number"
                        defaultValue={100}
                        className="bg-white/10 border-white/20 text-white"
                        placeholder="100"
                        required
                      />
                    </div>
                    <div className="flex space-x-2">
                      <Button type="submit" className="bg-coral hover:bg-coral/80 text-white">
                        Create API Key
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowApiKeyForm(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                )}

                {apiKeys.map((apiKey) => (
                  <div key={apiKey.id} className="glass rounded-xl p-4 border border-white/10">
                    <div className="flex items-center justify-between mb-3">
                      <div className="font-semibold text-white dark:text-white">{apiKey.name}</div>
                      <div className="flex items-center space-x-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(apiKey.key)}
                          className="text-blue-400 hover:text-blue-300"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteApiKeyMutation.mutate(apiKey.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="text-sm text-gray-400 dark:text-gray-400 mb-2">
                      Credits per $1: {apiKey.creditsPerDollar}
                    </div>
                    <div className="text-xs text-gray-500 font-mono bg-black/20 p-2 rounded">
                      {apiKey.key}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <div className="grid lg:grid-cols-2 gap-8">
              {/* Product Management */}
              <Card className="glass-dark border-white/20">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-white dark:text-white">Products</CardTitle>
                  <Button
                    onClick={() => setShowProductForm(!showProductForm)}
                    className="bg-coral hover:bg-coral/80 text-white"
                    size="sm"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Product
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  {showProductForm && (
                    <form onSubmit={handleProductSubmit} className="space-y-4 p-4 border border-white/20 rounded-lg">
                      <div>
                        <Label htmlFor="name" className="text-white dark:text-white">Product Name</Label>
                        <Input
                          id="name"
                          name="name"
                          defaultValue={editingProduct?.name || ''}
                          className="bg-white/10 border-white/20 text-white"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="description" className="text-white dark:text-white">Description</Label>
                        <Textarea
                          id="description"
                          name="description"
                          defaultValue={editingProduct?.description || ''}
                          className="bg-white/10 border-white/20 text-white"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="price" className="text-white dark:text-white">Price ($)</Label>
                        <Input
                          id="price"
                          name="price"
                          type="number"
                          step="0.01"
                          defaultValue={editingProduct?.price || ''}
                          className="bg-white/10 border-white/20 text-white"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="creditsPrice" className="text-white dark:text-white">Credits Price</Label>
                        <Input
                          id="creditsPrice"
                          name="creditsPrice"
                          type="number"
                          defaultValue={editingProduct?.creditsPrice || 0}
                          className="bg-white/10 border-white/20 text-white"
                          placeholder="Credits required to purchase"
                        />
                      </div>
                      <div>
                        <Label htmlFor="fileUrl" className="text-white dark:text-white">File URL</Label>
                        <Input
                          id="fileUrl"
                          name="fileUrl"
                          defaultValue={editingProduct?.fileUrl || ''}
                          className="bg-white/10 border-white/20 text-white"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="fileName" className="text-white dark:text-white">File Name</Label>
                        <Input
                          id="fileName"
                          name="fileName"
                          defaultValue={editingProduct?.fileName || ''}
                          className="bg-white/10 border-white/20 text-white"
                          required
                        />
                      </div>
                      <div className="flex space-x-2">
                        <Button type="submit" className="bg-coral hover:bg-coral/80 text-white">
                          {editingProduct ? 'Update' : 'Create'} Product
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => {
                            setShowProductForm(false);
                            setEditingProduct(null);
                          }}
                        >
                          Cancel
                        </Button>
                      </div>
                    </form>
                  )}

                  {products.map((product) => (
                    <div key={product.id} className="glass rounded-xl p-4 border border-white/10">
                      <div className="flex items-center justify-between mb-3">
                        <div className="font-semibold text-white dark:text-white">{product.name}</div>
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setEditingProduct(product);
                              setShowProductForm(true);
                            }}
                            className="text-blue-400 hover:text-blue-300"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => deleteProductMutation.mutate(product.id)}
                            className="text-red-400 hover:text-red-300"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="text-sm text-gray-400 dark:text-gray-400 mb-2">
                        {orders.filter(o => o.productId === product.id).length} sales
                      </div>
                      <div className="text-coral font-semibold">${product.price}</div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Recent Orders */}
              <Card className="glass-dark border-white/20">
                <CardHeader>
                  <CardTitle className="text-white dark:text-white">Recent Orders</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {orders.slice(0, 10).map((order) => (
                    <div key={order.id} className="glass rounded-xl p-4 border border-white/10">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-semibold text-white dark:text-white">
                            {order.user?.email || 'Unknown User'}
                          </div>
                          <div className="text-sm text-gray-400 dark:text-gray-400">
                            {order.product?.name || 'Unknown Product'}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-500">
                            {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'Unknown date'}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-coral font-semibold">${order.amount}</div>
                          <div className={`text-xs ${
                            order.status === 'completed' ? 'text-green-400' : 'text-yellow-400'
                          }`}>
                            {order.status}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
