import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Product } from '@shared/schema';
import { Code, Shield, Zap, Star, ArrowRight, Download, Users, Award } from 'lucide-react';

export default function Landing() {
  const { isAuthenticated } = useAuth();
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  return (
    <div className="min-h-screen ahx-bg-primary">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        {/* Background Grid Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="grid grid-cols-12 h-full">
            {[...Array(12)].map((_, i) => (
              <div key={i} className="border-r ahx-border-red"></div>
            ))}
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          {/* Main Hero Content */}
          <div className="text-center mb-16 lg:mb-20">
            <h1 className="text-4xl sm:text-6xl lg:text-8xl ahx-futuristic-text ahx-text-red mb-6 lg:mb-8 leading-tight">
              <span className="ahx-glow-red">AHX HUB</span>
            </h1>
            <div className="max-w-4xl mx-auto mb-8 lg:mb-12 px-4">
              <p className="text-lg sm:text-xl lg:text-2xl ahx-text-white mb-3 lg:mb-4 font-light">
                THE BEST COMPANY FOR ROBLOX ASSETS, ACROSS ALL GENRES
              </p>
              <p className="text-base sm:text-lg lg:text-xl ahx-text-gray mb-2">
                From MilSim To Roleplay, We Got Them All.
              </p>
              <p className="text-sm sm:text-base lg:text-lg ahx-text-gray">
                Professional-grade premium assets designed for elite developers
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 lg:gap-6 justify-center mb-12 lg:mb-16 px-4">
              <Button 
                onClick={() => window.location.href = isAuthenticated ? '/products' : '/api/login'}
                className="ahx-bg-red-glow ahx-text-white px-8 sm:px-12 py-4 lg:py-6 text-base lg:text-lg ahx-futuristic-text hover:ahx-hover-glow"
                size="lg"
              >
                GET ACCESS
              </Button>
              <Button 
                variant="outline"
                className="ahx-border-red ahx-text-red hover:ahx-bg-red hover:ahx-text-white px-8 sm:px-12 py-4 lg:py-6 text-base lg:text-lg border-2"
                size="lg"
              >
                VIEW CATALOG
              </Button>
            </div>
          </div>

          {/* Feature Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 lg:gap-6 mb-16 lg:mb-20 px-4">
            <div className="ahx-card p-4 lg:p-6 text-center ahx-hover-glow">
              <Code className="w-6 lg:w-8 h-6 lg:h-8 ahx-text-red mx-auto mb-2 lg:mb-3" />
              <h3 className="ahx-text-white font-semibold text-sm lg:text-base">Assets</h3>
            </div>
            <div className="ahx-card p-4 lg:p-6 text-center ahx-hover-glow">
              <Shield className="w-6 lg:w-8 h-6 lg:h-8 ahx-text-red mx-auto mb-2 lg:mb-3" />
              <h3 className="ahx-text-white font-semibold text-sm lg:text-base">Security</h3>
            </div>
            <div className="ahx-card p-4 lg:p-6 text-center ahx-hover-glow">
              <Zap className="w-6 lg:w-8 h-6 lg:h-8 ahx-text-red mx-auto mb-2 lg:mb-3" />
              <h3 className="ahx-text-white font-semibold text-sm lg:text-base">Performance</h3>
            </div>
            <div className="ahx-card p-4 lg:p-6 text-center ahx-hover-glow">
              <Users className="w-6 lg:w-8 h-6 lg:h-8 ahx-text-red mx-auto mb-2 lg:mb-3" />
              <h3 className="ahx-text-white font-semibold text-sm lg:text-base">Community</h3>
            </div>
            <div className="ahx-card p-4 lg:p-6 text-center ahx-hover-glow col-span-2 sm:col-span-1">
              <Award className="w-6 lg:w-8 h-6 lg:h-8 ahx-text-red mx-auto mb-2 lg:mb-3" />
              <h3 className="ahx-text-white font-semibold text-sm lg:text-base">Premium</h3>
            </div>
          </div>
        </div>
      </section>

      {/* Recent Releases Section */}
      <section className="py-12 lg:py-20 border-t ahx-border-red">
        <div className="max-w-7xl mx-auto px-4 lg:px-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 lg:mb-12 gap-4">
            <h2 className="text-2xl lg:text-4xl ahx-futuristic-text ahx-text-white">Recent Releases</h2>
            <Button variant="ghost" className="ahx-text-red hover:ahx-text-white text-sm lg:text-base">
              View All <ArrowRight className="ml-2 w-3 lg:w-4 h-3 lg:h-4" />
            </Button>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="ahx-card p-4 lg:p-6 animate-pulse">
                  <div className="aspect-video ahx-bg-red opacity-20 rounded-lg mb-4"></div>
                  <div className="h-6 ahx-bg-red opacity-20 rounded mb-2"></div>
                  <div className="h-4 ahx-bg-red opacity-20 rounded w-2/3"></div>
                </div>
              ))}
            </div>
          ) : products.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
              {products.slice(0, 6).map((product) => (
                <div key={product.id} className="ahx-card overflow-hidden ahx-hover-glow">
                  <div className="aspect-video ahx-gradient-bg relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Code className="w-12 lg:w-16 h-12 lg:h-16 ahx-text-red opacity-50" />
                    </div>
                    <div className="absolute top-3 lg:top-4 right-3 lg:right-4 px-2 lg:px-3 py-1 ahx-bg-red-glow rounded">
                      <span className="text-xs font-bold ahx-text-white">NEW</span>
                    </div>
                  </div>
                  <div className="p-4 lg:p-6">
                    <h3 className="text-lg lg:text-xl font-bold ahx-text-white mb-2">{product.name}</h3>
                    <p className="ahx-text-gray text-sm mb-3 lg:mb-4 line-clamp-2">{product.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-xl lg:text-2xl font-bold ahx-text-red">${product.price}</span>
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-3 lg:w-4 h-3 lg:h-4 ahx-text-red fill-current" />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 lg:py-16 px-4">
              <Code className="w-16 lg:w-24 h-16 lg:h-24 ahx-text-red opacity-50 mx-auto mb-4 lg:mb-6" />
              <h3 className="text-xl lg:text-2xl font-bold ahx-text-white mb-3 lg:mb-4">Premium Assets Coming Soon</h3>
              <p className="ahx-text-gray text-sm lg:text-base">Elite Roblox content is being prepared for our marketplace.</p>
            </div>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 lg:py-20 border-t ahx-border-red">
        <div className="max-w-7xl mx-auto px-4 lg:px-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8 text-center">
            <div className="ahx-card p-6 lg:p-8 ahx-hover-glow">
              <div className="text-2xl lg:text-4xl font-bold ahx-text-red mb-1 lg:mb-2">{products.length}+</div>
              <div className="ahx-text-gray text-sm lg:text-base">Premium Assets</div>
            </div>
            <div className="ahx-card p-6 lg:p-8 ahx-hover-glow">
              <div className="text-2xl lg:text-4xl font-bold ahx-text-red mb-1 lg:mb-2">50K+</div>
              <div className="ahx-text-gray text-sm lg:text-base">Active Users</div>
            </div>
            <div className="ahx-card p-6 lg:p-8 ahx-hover-glow">
              <div className="text-2xl lg:text-4xl font-bold ahx-text-red mb-1 lg:mb-2">99.9%</div>
              <div className="ahx-text-gray text-sm lg:text-base">Uptime</div>
            </div>
            <div className="ahx-card p-6 lg:p-8 ahx-hover-glow">
              <div className="text-2xl lg:text-4xl font-bold ahx-text-red mb-1 lg:mb-2">24/7</div>
              <div className="ahx-text-gray text-sm lg:text-base">Support</div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}