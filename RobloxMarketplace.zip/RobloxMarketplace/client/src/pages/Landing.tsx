import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { ProductCard } from '@/components/ProductCard';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { Product } from '@shared/schema';
import { Play, Lock, Zap, Star, Headphones } from 'lucide-react';

export default function Landing() {
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  const featuredProduct = products[0];

  return (
    <div className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-20 min-h-screen flex items-center relative overflow-hidden floating-particles">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8 animate-slide-up">
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-bold text-black dark:text-white leading-tight">
                Premium
                <span className="text-primary"> Roblox Scripts</span>
                <br />& Models
              </h1>
              <p className="text-xl text-gray-700 dark:text-gray-300 leading-relaxed">
                Discover high-quality, secure scripts and models crafted by professionals. 
                Instant delivery via Discord after purchase.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={() => window.location.href = '/api/login'}
                className="px-8 py-4 bg-primary hover:bg-primary/80 text-white font-semibold"
                size="lg"
              >
                Get Started
              </Button>
              <Button 
                variant="outline"
                className="px-8 py-4 border-white/20 text-black dark:text-white hover:bg-white/10 dark:hover:bg-white/10 font-semibold"
                size="lg"
              >
                Learn More
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-black dark:text-white">{products.length}+</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Products</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-black dark:text-white">1K+</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Customers</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-black dark:text-white">4.9</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Rating</div>
              </div>
            </div>
          </div>

          {/* Product Showcase */}
          {featuredProduct && (
            <div className="relative animate-float">
              <div className="glass-dark rounded-2xl p-8 space-y-6 border border-white/20">
                <div className="aspect-video bg-gradient-to-br from-electric to-midnight rounded-xl relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Play className="text-6xl text-white/50" />
                  </div>
                  <div className="absolute top-4 right-4 px-3 py-1 bg-primary rounded-full text-sm text-white font-semibold">
                    Featured
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h3 className="text-2xl font-bold text-black dark:text-white">{featuredProduct.name}</h3>
                  <p className="text-gray-700 dark:text-gray-300">{featuredProduct.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="text-3xl font-bold text-primary">${featuredProduct.price}</div>
                    <div className="flex items-center space-x-2 text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                      <span className="text-white dark:text-white text-sm">(127 reviews)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Products Section */}
      <section className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold text-black dark:text-white">Our Products</h2>
            <p className="text-xl text-gray-700 dark:text-gray-300">Premium scripts and models for your Roblox projects</p>
          </div>

          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="glass-dark rounded-xl p-6 animate-pulse border border-white/20">
                  <div className="aspect-video bg-gray-600 rounded-lg mb-4"></div>
                  <div className="h-6 bg-gray-600 rounded mb-2"></div>
                  <div className="h-4 bg-gray-600 rounded mb-4"></div>
                  <div className="flex justify-between">
                    <div className="h-8 w-20 bg-gray-600 rounded"></div>
                    <div className="h-8 w-24 bg-gray-600 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.slice(0, 6).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold text-black dark:text-white">Why Choose AHX Hub?</h2>
            <p className="text-xl text-gray-700 dark:text-gray-300">Premium quality, security, and instant delivery</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="glass-dark rounded-xl p-6 text-center hover:bg-white/10 transition-all border border-white/20">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-electric rounded-xl mx-auto mb-4 flex items-center justify-center">
                <Lock className="text-2xl text-white" />
              </div>
              <h3 className="text-xl font-semibold text-black dark:text-white mb-2">Secure</h3>
              <p className="text-gray-700 dark:text-gray-300 text-sm">Bank-level security with encrypted payments</p>
            </div>

            <div className="glass-dark rounded-xl p-6 text-center hover:bg-white/10 transition-all border border-white/20">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-electric rounded-xl mx-auto mb-4 flex items-center justify-center">
                <Zap className="text-2xl text-white" />
              </div>
              <h3 className="text-xl font-semibold text-black dark:text-white mb-2">Instant</h3>
              <p className="text-gray-700 dark:text-gray-300 text-sm">Immediate delivery via Discord</p>
            </div>

            <div className="glass-dark rounded-xl p-6 text-center hover:bg-white/10 transition-all border border-white/20">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-electric rounded-xl mx-auto mb-4 flex items-center justify-center">
                <Star className="text-2xl text-white" />
              </div>
              <h3 className="text-xl font-semibold text-black dark:text-white mb-2">Quality</h3>
              <p className="text-gray-700 dark:text-gray-300 text-sm">Professional-grade scripts and models</p>
            </div>

            <div className="glass-dark rounded-xl p-6 text-center hover:bg-white/10 transition-all border border-white/20">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-electric rounded-xl mx-auto mb-4 flex items-center justify-center">
                <Headphones className="text-2xl text-white" />
              </div>
              <h3 className="text-xl font-semibold text-black dark:text-white mb-2">Support</h3>
              <p className="text-gray-700 dark:text-gray-300 text-sm">24/7 customer support via Discord</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
