import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { useAuth } from '@/hooks/useAuth';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShoppingBag, Settings, Package } from 'lucide-react';

export default function Home() {
  const { user } = useAuth();
  const isAdmin = user?.email === 'talonlol69420@gmail.com';

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="pt-20 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center space-y-4 mb-16">
            <h1 className="text-4xl font-bold text-white dark:text-white">
              Welcome back, {user?.firstName || user?.email}!
            </h1>
            <p className="text-xl text-gray-300 dark:text-gray-300">
              Ready to explore premium Roblox content?
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            <Link href="/product">
              <Card className="glass-dark hover:bg-white/10 transition-all transform hover:scale-105 cursor-pointer border-white/20">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-coral to-electric rounded-xl mx-auto mb-4 flex items-center justify-center">
                    <Package className="text-2xl text-white" />
                  </div>
                  <CardTitle className="text-white dark:text-white">Browse Products</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 dark:text-gray-300 text-sm text-center">
                    Explore our premium collection of Roblox scripts and models
                  </p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/dashboard">
              <Card className="glass-dark hover:bg-white/10 transition-all transform hover:scale-105 cursor-pointer border-white/20">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-coral to-electric rounded-xl mx-auto mb-4 flex items-center justify-center">
                    <ShoppingBag className="text-2xl text-white" />
                  </div>
                  <CardTitle className="text-white dark:text-white">My Purchases</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 dark:text-gray-300 text-sm text-center">
                    View your purchase history and download files
                  </p>
                </CardContent>
              </Card>
            </Link>

            {isAdmin && (
              <Link href="/admin">
                <Card className="glass-dark hover:bg-white/10 transition-all transform hover:scale-105 cursor-pointer border-white/20">
                  <CardHeader className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-coral to-electric rounded-xl mx-auto mb-4 flex items-center justify-center">
                      <Settings className="text-2xl text-white" />
                    </div>
                    <CardTitle className="text-white dark:text-white">Admin Panel</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300 dark:text-gray-300 text-sm text-center">
                      Manage products and view analytics
                    </p>
                  </CardContent>
                </Card>
              </Link>
            )}
          </div>

          <div className="text-center">
            <Link href="/product">
              <Button 
                size="lg"
                className="bg-coral hover:bg-coral/80 text-white px-8 py-4 text-lg"
              >
                Get Started Now
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
