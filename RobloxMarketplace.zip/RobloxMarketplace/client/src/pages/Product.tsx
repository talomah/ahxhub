import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { Product as ProductType } from '@shared/schema';
import { Link } from 'wouter';
import { Star, Shield, Download, Clock } from 'lucide-react';

export default function Product() {
  const { data: products = [], isLoading } = useQuery<ProductType[]>({
    queryKey: ['/api/products'],
  });

  const product = products[0]; // Single product for now

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <div className="pt-20 min-h-screen flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-coral border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <div className="pt-20 min-h-screen flex items-center justify-center">
          <Card className="glass-dark border-white/20 max-w-md">
            <CardContent className="p-8 text-center">
              <h2 className="text-xl font-bold text-white dark:text-white mb-4">No Products Available</h2>
              <p className="text-gray-300 dark:text-gray-300 mb-6">
                Products will be available soon. Check back later!
              </p>
              <Link href="/">
                <Button className="bg-coral hover:bg-coral/80 text-white">
                  Go Back Home
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Product Media */}
            <div className="space-y-6">
              <div className="aspect-video bg-gradient-to-br from-electric to-midnight rounded-2xl relative overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <Shield className="w-20 h-20 text-white/50 mx-auto mb-4" />
                    <p className="text-white/70 text-lg">Preview Available</p>
                  </div>
                </div>
                <div className="absolute top-6 right-6 px-4 py-2 bg-coral rounded-full text-white font-semibold">
                  Premium
                </div>
              </div>
              
              {/* Features */}
              <div className="grid grid-cols-2 gap-4">
                <Card className="glass-dark border-white/20">
                  <CardContent className="p-4 text-center">
                    <Download className="w-8 h-8 text-coral mx-auto mb-2" />
                    <p className="text-sm text-white dark:text-white font-medium">Instant Download</p>
                  </CardContent>
                </Card>
                <Card className="glass-dark border-white/20">
                  <CardContent className="p-4 text-center">
                    <Shield className="w-8 h-8 text-coral mx-auto mb-2" />
                    <p className="text-sm text-white dark:text-white font-medium">Secure & Safe</p>
                  </CardContent>
                </Card>
                <Card className="glass-dark border-white/20">
                  <CardContent className="p-4 text-center">
                    <Clock className="w-8 h-8 text-coral mx-auto mb-2" />
                    <p className="text-sm text-white dark:text-white font-medium">24/7 Support</p>
                  </CardContent>
                </Card>
                <Card className="glass-dark border-white/20">
                  <CardContent className="p-4 text-center">
                    <Star className="w-8 h-8 text-coral mx-auto mb-2" />
                    <p className="text-sm text-white dark:text-white font-medium">Premium Quality</p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl font-bold text-white dark:text-white">{product.name}</h1>
                
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <span className="text-gray-300 dark:text-gray-300">(127 reviews)</span>
                </div>

                <div className="text-5xl font-bold text-coral">${product.price}</div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-white dark:text-white">Description</h3>
                <p className="text-gray-300 dark:text-gray-300 leading-relaxed">
                  {product.description}
                </p>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-white dark:text-white">Features</h3>
                <ul className="space-y-2 text-gray-300 dark:text-gray-300">
                  <li className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-coral rounded-full"></div>
                    <span>Professional grade quality</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-coral rounded-full"></div>
                    <span>Instant delivery via Discord</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-coral rounded-full"></div>
                    <span>Regular updates and support</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-coral rounded-full"></div>
                    <span>Anti-detection technology</span>
                  </li>
                </ul>
              </div>

              <div className="space-y-4">
                <Link href={`/checkout?productId=${product.id}`}>
                  <Button 
                    size="lg" 
                    className="w-full bg-coral hover:bg-coral/80 text-white py-4 text-lg font-semibold"
                  >
                    Buy Now - ${product.price}
                  </Button>
                </Link>
                
                <div className="text-center text-sm text-gray-400 dark:text-gray-400">
                  Secure checkout powered by Stripe
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
