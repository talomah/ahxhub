import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { isUnauthorizedError } from '@/lib/authUtils';
import { useEffect } from 'react';
import { Order, Product } from '@shared/schema';
import { Download, ShoppingBag, DollarSign, Calendar } from 'lucide-react';

export default function Dashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: orders = [], isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ['/api/user/orders'],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ['/api/products'],
    enabled: isAuthenticated,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <div className="pt-20 min-h-screen flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-coral border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  const completedOrders = orders.filter(order => order.status === 'completed');
  const totalSpent = completedOrders.reduce((sum, order) => sum + parseFloat(order.amount.toString()), 0);

  const getProductName = (productId: number) => {
    const product = products.find(p => p.id === productId);
    return product?.name || 'Unknown Product';
  };

  const handleDownload = (order: Order) => {
    toast({
      title: "Download Started",
      description: "Your file will be sent to your Discord shortly.",
    });
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="pt-20 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="space-y-8">
            <div className="text-center space-y-4">
              <h1 className="text-4xl font-bold text-white dark:text-white">Dashboard</h1>
              <p className="text-xl text-gray-300 dark:text-gray-300">
                Welcome back, {user?.firstName || user?.email}!
              </p>
            </div>

            {/* Stats Cards */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="glass-dark border-white/20">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-coral to-electric rounded-lg mx-auto mb-4 flex items-center justify-center">
                    <ShoppingBag className="text-white" />
                  </div>
                  <div className="text-3xl font-bold text-coral">{completedOrders.length}</div>
                  <div className="text-sm text-gray-400 dark:text-gray-400">Total Purchases</div>
                </CardContent>
              </Card>

              <Card className="glass-dark border-white/20">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-coral to-electric rounded-lg mx-auto mb-4 flex items-center justify-center">
                    <DollarSign className="text-white" />
                  </div>
                  <div className="text-3xl font-bold text-electric">${totalSpent.toFixed(2)}</div>
                  <div className="text-sm text-gray-400 dark:text-gray-400">Total Spent</div>
                </CardContent>
              </Card>

              <Card className="glass-dark border-white/20">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-coral to-electric rounded-lg mx-auto mb-4 flex items-center justify-center">
                    <Download className="text-white" />
                  </div>
                  <div className="text-3xl font-bold text-white dark:text-white">{completedOrders.length * 3}</div>
                  <div className="text-sm text-gray-400 dark:text-gray-400">Downloads</div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Purchases */}
            <Card className="glass-dark border-white/20">
              <CardHeader>
                <CardTitle className="text-white dark:text-white">Recent Purchases</CardTitle>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin w-8 h-8 border-4 border-coral border-t-transparent rounded-full mx-auto" />
                  </div>
                ) : orders.length === 0 ? (
                  <div className="text-center py-8">
                    <ShoppingBag className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-400 dark:text-gray-400 mb-4">No purchases yet</p>
                    <Button 
                      onClick={() => window.location.href = '/product'}
                      className="bg-coral hover:bg-coral/80 text-white"
                    >
                      Browse Products
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <div key={order.id} className="glass rounded-xl p-4 flex items-center justify-between border border-white/10">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-coral to-electric rounded-lg flex items-center justify-center">
                            <Download className="text-white" />
                          </div>
                          <div>
                            <div className="font-semibold text-white dark:text-white">
                              {getProductName(order.productId)}
                            </div>
                            <div className="text-sm text-gray-400 dark:text-gray-400 flex items-center space-x-1">
                              <Calendar className="w-4 h-4" />
                              <span>
                                {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'Unknown date'}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <span className="text-coral font-semibold">${order.amount}</span>
                          <div className="flex items-center space-x-2">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              order.status === 'completed' 
                                ? 'bg-green-500/20 text-green-400' 
                                : 'bg-yellow-500/20 text-yellow-400'
                            }`}>
                              {order.status}
                            </span>
                            {order.status === 'completed' && (
                              <Button
                                size="sm"
                                onClick={() => handleDownload(order)}
                                className="bg-electric hover:bg-electric/80 text-white"
                              >
                                <Download className="w-4 h-4 mr-2" />
                                Download
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
