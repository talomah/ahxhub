import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Code, Palette, Gamepad2, Shield, Zap, Users, MessageCircle, Star } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: Code,
      title: "Custom Script Development",
      description: "Bespoke Roblox assets tailored to your specific game requirements",
      features: ["Advanced Anti-Cheat", "Performance Optimized", "Full Documentation", "Lifetime Support"],
      price: "Starting at $500"
    },
    {
      icon: Palette,
      title: "UI/UX Design Services",
      description: "Professional interface design for Roblox games and applications",
      features: ["Modern Designs", "Mobile Responsive", "Custom Animations", "Brand Integration"],
      price: "Starting at $300"
    },
    {
      icon: Gamepad2,
      title: "Game Development",
      description: "Complete game development from concept to deployment",
      features: ["Full Game Creation", "Monetization Setup", "Testing & QA", "Post-Launch Support"],
      price: "Starting at $2000"
    },
    {
      icon: Shield,
      title: "Security Auditing",
      description: "Comprehensive security analysis and vulnerability assessment",
      features: ["Code Review", "Exploit Detection", "Security Hardening", "Compliance Reports"],
      price: "Starting at $800"
    },
    {
      icon: Zap,
      title: "Performance Optimization",
      description: "Boost your game's performance with expert optimization",
      features: ["Code Optimization", "Memory Management", "FPS Improvements", "Load Time Reduction"],
      price: "Starting at $400"
    },
    {
      icon: Users,
      title: "Team Training",
      description: "Professional training sessions for your development team",
      features: ["Custom Curriculum", "1-on-1 Mentoring", "Best Practices", "Certification"],
      price: "Starting at $1200"
    }
  ];

  return (
    <div className="min-h-screen ahx-bg-primary">
      <Navigation />
      
      <section className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-6">
          {/* Hero Section */}
          <div className="text-center mb-20">
            <h1 className="text-6xl ahx-futuristic-text ahx-text-red mb-8 ahx-glow-red">
              PROFESSIONAL SERVICES
            </h1>
            <p className="text-2xl ahx-text-white mb-4">
              Elite development services for serious projects
            </p>
            <p className="text-xl ahx-text-gray max-w-3xl mx-auto">
              Our team of expert developers offers custom solutions for enterprises, 
              game studios, and ambitious creators who demand excellence.
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
            {services.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <div key={index} className="ahx-card p-8 ahx-hover-glow">
                  <IconComponent className="w-16 h-16 ahx-text-red mb-6" />
                  <h3 className="text-2xl font-bold ahx-text-white mb-4">{service.title}</h3>
                  <p className="ahx-text-gray mb-6">{service.description}</p>
                  
                  <div className="space-y-2 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center">
                        <div className="w-2 h-2 ahx-bg-red rounded-full mr-3"></div>
                        <span className="ahx-text-gray text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="border-t ahx-border-red pt-6">
                    <p className="text-2xl font-bold ahx-text-red mb-4">{service.price}</p>
                    <Button className="w-full ahx-bg-red-glow ahx-text-white hover:ahx-hover-glow">
                      Get Quote
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Process Section */}
          <div className="ahx-card p-12 mb-20">
            <h2 className="text-4xl ahx-futuristic-text ahx-text-white text-center mb-12">
              OUR DEVELOPMENT PROCESS
            </h2>
            
            <div className="grid md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 ahx-bg-red-glow rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold ahx-text-white">1</span>
                </div>
                <h3 className="text-xl font-bold ahx-text-white mb-2">Consultation</h3>
                <p className="ahx-text-gray">Detailed analysis of your requirements and goals</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 ahx-bg-red-glow rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold ahx-text-white">2</span>
                </div>
                <h3 className="text-xl font-bold ahx-text-white mb-2">Planning</h3>
                <p className="ahx-text-gray">Comprehensive project roadmap and timeline</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 ahx-bg-red-glow rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold ahx-text-white">3</span>
                </div>
                <h3 className="text-xl font-bold ahx-text-white mb-2">Development</h3>
                <p className="ahx-text-gray">Expert implementation with regular updates</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 ahx-bg-red-glow rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold ahx-text-white">4</span>
                </div>
                <h3 className="text-xl font-bold ahx-text-white mb-2">Delivery</h3>
                <p className="ahx-text-gray">Complete testing, documentation, and deployment</p>
              </div>
            </div>
          </div>

          {/* Contact Section */}
          <div className="text-center">
            <h2 className="text-4xl ahx-futuristic-text ahx-text-white mb-8">
              READY TO START YOUR PROJECT?
            </h2>
            <p className="text-xl ahx-text-gray mb-12">
              Contact our expert team for a free consultation and detailed quote
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Button 
                className="ahx-bg-red-glow ahx-text-white px-12 py-6 text-lg ahx-futuristic-text hover:ahx-hover-glow"
                size="lg"
              >
                <MessageCircle className="mr-3 w-6 h-6" />
                CONTACT US
              </Button>
              <Button 
                variant="outline"
                className="ahx-border-red ahx-text-red hover:ahx-bg-red hover:ahx-text-white px-12 py-6 text-lg border-2"
                size="lg"
              >
                VIEW PORTFOLIO
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}