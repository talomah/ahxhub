import { Code } from 'lucide-react';

export function Footer() {
  return (
    <footer className="py-12 lg:py-16 border-t ahx-border-red">
      <div className="max-w-7xl mx-auto px-4 lg:px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 ahx-card ahx-glow-red flex items-center justify-center">
                <Code className="ahx-text-red text-xl" />
              </div>
              <span className="text-2xl ahx-futuristic-text ahx-text-red">AHX Hub</span>
            </div>
            <p className="ahx-text-gray">
              Premium Roblox assets for professional developers and serious creators.
            </p>
          </div>
          
          <div>
            <h5 className="font-semibold ahx-text-white mb-4">Products</h5>
            <ul className="space-y-2">
              <li><a href="/products" className="ahx-text-gray hover:ahx-text-red transition-colors">Premium Assets</a></li>
              <li><a href="/products" className="ahx-text-gray hover:ahx-text-red transition-colors">Quality Content</a></li>
              <li><a href="/products" className="ahx-text-gray hover:ahx-text-red transition-colors">Elite Resources</a></li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-semibold ahx-text-white mb-4">Community</h5>
            <ul className="space-y-2">
              <li><a href="/discord" className="ahx-text-gray hover:ahx-text-red transition-colors">Discord Server</a></li>
              <li><a href="/services" className="ahx-text-gray hover:ahx-text-red transition-colors">Custom Services</a></li>
              <li><a href="#" className="ahx-text-gray hover:ahx-text-red transition-colors">Support Center</a></li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-semibold ahx-text-white mb-4">Legal</h5>
            <ul className="space-y-2">
              <li><a href="#" className="ahx-text-gray hover:ahx-text-red transition-colors">Terms of Service</a></li>
              <li><a href="#" className="ahx-text-gray hover:ahx-text-red transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="ahx-text-gray hover:ahx-text-red transition-colors">Refund Policy</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t ahx-border-red mt-12 pt-8 text-center ahx-text-gray">
          <p>&copy; 2024 AHX Hub. All rights reserved. Elite Roblox Assets.</p>
        </div>
      </div>
    </footer>
  );
}
