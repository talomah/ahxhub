import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { ThemeToggle } from './ThemeToggle';
import { Code, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

export function Navigation() {
  const { user, isAuthenticated } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isAdmin = user?.email === 'talonlol69420@gmail.com';

  return (
    <nav className="fixed top-0 w-full z-50 ahx-bg-primary border-b ahx-border-red">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-4">
            <div className="w-12 h-12 ahx-card ahx-glow-red flex items-center justify-center">
              <Code className="ahx-text-red text-xl" />
            </div>
            <span className="text-3xl ahx-futuristic-text ahx-text-red ahx-glow-red">AHX Hub</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/">
              <Button variant="ghost" className="ahx-text-white hover:ahx-text-red transition-colors duration-300">
                Home
              </Button>
            </Link>
            <Link href="/products">
              <Button variant="ghost" className="ahx-text-white hover:ahx-text-red transition-colors duration-300">
                Products
              </Button>
            </Link>
            <Link href="/discord">
              <Button variant="ghost" className="ahx-text-white hover:ahx-text-red transition-colors duration-300">
                Join Discord
              </Button>
            </Link>
            <Link href="/services">
              <Button variant="ghost" className="ahx-text-white hover:ahx-text-red transition-colors duration-300">
                Other Services
              </Button>
            </Link>
            {isAuthenticated && isAdmin && (
              <Link href="/admin">
                <Button variant="ghost" className="ahx-text-red hover:ahx-glow-red">
                  Admin
                </Button>
              </Link>
            )}
            
            <ThemeToggle />
            
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <span className="ahx-text-gray">
                  {user?.firstName || user?.email}
                </span>
                <Button
                  onClick={() => window.location.href = '/api/logout'}
                  className="ahx-bg-red ahx-text-white hover:ahx-hover-glow"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <Button
                  onClick={() => window.location.href = '/api/login'}
                  variant="ghost"
                  className="ahx-text-white hover:ahx-text-red"
                >
                  Login
                </Button>
                <Button
                  onClick={() => window.location.href = '/api/login'}
                  className="ahx-bg-red-glow ahx-text-white hover:ahx-hover-glow"
                >
                  Get Access
                </Button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className="ahx-text-white" />
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden ahx-bg-primary border-t ahx-border-red">
          <div className="px-4 pt-4 pb-6 space-y-3">
            {/* Mobile Navigation Links */}
            <Link href="/" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="ghost" className="w-full text-left ahx-text-white hover:ahx-text-red">
                Home
              </Button>
            </Link>
            <Link href="/products" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="ghost" className="w-full text-left ahx-text-white hover:ahx-text-red">
                Products
              </Button>
            </Link>
            <Link href="/discord" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="ghost" className="w-full text-left ahx-text-white hover:ahx-text-red">
                Join Discord
              </Button>
            </Link>
            <Link href="/services" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="ghost" className="w-full text-left ahx-text-white hover:ahx-text-red">
                Other Services
              </Button>
            </Link>
            
            {/* Admin Link */}
            {isAuthenticated && isAdmin && (
              <Link href="/admin" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="ghost" className="w-full text-left ahx-text-red hover:ahx-glow-red">
                  Admin
                </Button>
              </Link>
            )}
            
            {/* Theme Toggle */}
            <div className="pt-2 border-t ahx-border-red">
              <ThemeToggle />
            </div>
            
            {/* Auth Buttons */}
            {isAuthenticated ? (
              <div className="pt-2 space-y-3">
                <div className="ahx-text-gray text-sm px-3">
                  {user?.firstName || user?.email}
                </div>
                <Button
                  onClick={() => window.location.href = '/api/logout'}
                  className="w-full ahx-bg-red ahx-text-white hover:ahx-hover-glow"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <div className="pt-2 space-y-3">
                <Button
                  onClick={() => window.location.href = '/api/login'}
                  variant="ghost"
                  className="w-full ahx-text-white hover:ahx-text-red"
                >
                  Login
                </Button>
                <Button
                  onClick={() => window.location.href = '/api/login'}
                  className="w-full ahx-bg-red-glow ahx-text-white hover:ahx-hover-glow"
                >
                  Get Access
                </Button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
