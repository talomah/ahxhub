import { Product } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Code, Star } from 'lucide-react';
import { Link } from 'wouter';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <Card className="glass-dark hover:bg-white/10 transition-all transform hover:scale-105 cursor-pointer border-white/20">
      <CardContent className="p-6">
        <div className="aspect-video bg-gradient-to-br from-electric to-midnight rounded-lg mb-4 relative overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <Code className="text-3xl text-white/50" />
          </div>
          <div className="absolute top-4 right-4 px-3 py-1 bg-primary rounded-full text-sm text-white font-semibold">
            Featured
          </div>
        </div>
        
        <h3 className="text-xl font-semibold text-black dark:text-white mb-2">{product.name}</h3>
        <p className="text-gray-700 dark:text-gray-300 text-sm mb-4 line-clamp-2">{product.description}</p>
        
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-primary">${product.price}</span>
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1 text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current" />
              ))}
            </div>
            <span className="text-white text-sm">(127)</span>
          </div>
        </div>
        
        <Link href="/product">
          <Button className="w-full mt-4 bg-primary hover:bg-primary/80 text-white">
            View Details
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
